from modelos.multilista import Multilist
from entidades.grupo import Grupo


class GrupoCRUD:
    """Operaciones CRUD para grupos de investigación."""

    def __init__(self, multilist: Multilist):
        """Inicializa el CRUD con una multilista compartida."""
        self.multilist = multilist

    def _next_id(self) -> int:
        """Genera el siguiente ID entero secuencial disponible para un grupo."""
        max_id = 0
        current = self.multilist.head_group
        while current is not None:
            gid = getattr(current.data, 'id', None)
            try:
                gid_int = int(gid)
                if gid_int > max_id:
                    max_id = gid_int
            except (TypeError, ValueError):
                pass
            current = current.next
        return max_id + 1

    def create(self, grupo: Grupo):
        """Inserta un nuevo grupo. Auto-genera un id entero secuencial si el grupo no trae id.
        Retorna False si ya existe un grupo con el mismo codigo_gruplac."""
        if grupo.codigo_gruplac and self.get_by_code(grupo.codigo_gruplac) is not None:
            return False
        # Auto-asignar ID entero secuencial si no viene uno numérico válido
        try:
            int(grupo.id)
        except (TypeError, ValueError):
            grupo.id = self._next_id()
        self.multilist.add_group(grupo)
        return True

    def list_all(self):
        """Retorna lista de grupos activos."""
        return list(self.multilist.iterate_groups())

    def get_by_id(self, group_id):
        """Retorna el grupo por id, o None si no existe."""
        node = self.multilist.get_group_by_id(group_id)
        if node is None:
            return None
        return node.data

    def get_by_code(self, codigo_gruplac):
        """Retorna el grupo por codigo, o None si no existe."""
        node = self.multilist.get_group_by_code(codigo_gruplac)
        if node is None:
            return None
        return node.data

    def update(self, group_id, **fields):
        """Actualiza campos del grupo."""
        grupo = self.get_by_id(group_id)
        if grupo is None:
            return False
        for key, value in fields.items():
            if hasattr(grupo, key):
                setattr(grupo, key, value)
        return True

    def deactivate(self, group_id):
        """Desactiva el grupo."""
        return self.multilist.deactivate_group(group_id)

    def activate(self, group_id):
        """Activa el grupo."""
        node = self.multilist.get_group_by_id(group_id)
        if node is None:
            return False
        node.active = True
        return True

    def delete(self, group_id):
        """Elimina físicamente el grupo."""
        return self.multilist.remove_group(group_id)

    def add_member(self, group_id, investigador):
        """Agrega un integrante al grupo en la multilista."""
        return self.multilist.add_investigador_to_group(group_id, investigador)

    def remove_member(self, group_id, cedula):
        """Quita un integrante del grupo en la multilista."""
        return self.multilist.remove_investigador_from_group(group_id, cedula)

    def list_members(self, group_id):
        """Retorna los integrantes activos del grupo desde la multilista."""
        return self.multilist.get_investigadores_by_grupo(group_id)

    def list_products(self, group_id):
        """Retorna los productos del grupo desde la multilista."""
        return self.multilist.get_productos_by_grupo(group_id)